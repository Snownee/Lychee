@NullMarked
package snownee.lychee.compat.recipeviewer.emi.element;

import org.jspecify.annotations.NullMarked;