@NullMarked
package snownee.lychee.compat.recipeviewer.emi.recipe;

import org.jspecify.annotations.NullMarked;