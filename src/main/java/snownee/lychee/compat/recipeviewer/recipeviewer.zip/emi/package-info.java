@NullMarked
package snownee.lychee.compat.recipeviewer.emi;

import org.jspecify.annotations.NullMarked;