@NullMarked
package snownee.lychee.compat.recipeviewer.emi.category;

import org.jspecify.annotations.NullMarked;