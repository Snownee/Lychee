@NullMarked
package snownee.lychee.compat.recipeviewer.emi.ingredient;

import org.jspecify.annotations.NullMarked;